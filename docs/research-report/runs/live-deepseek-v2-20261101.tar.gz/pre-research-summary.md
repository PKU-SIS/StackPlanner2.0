# Pre-Research Synthesis: Google's A2A Protocol and Anthropic's MCP — Differences, Connections, Innovations, and Target Problems

**Report:** r1 · **Action:** spact_call_00_zyS9WEaA3nMxYTKalTFG4725 · **Pass:** broad pre-research (no assigned gaps)
**Material inventory:** 60 documents saved (S1–S60 / m1–m60) from six searches. Sources read in full for this synthesis: S28 (m28), S21 (m21), S11 (m11), S9 (m9), S44 (m44), S4 (m4). Other cited materials are used at the level of the provider's saved summary/excerpt and are labelled accordingly.

---

## 1. The single most important framing: two protocols, two different jobs

The relationship is **complementary, not competitive**, and Google said so on day one. In the launch post for the Agent2Agent (A2A) protocol, published **9 April 2025**, Google Cloud states plainly: "A2A is an open protocol that **complements** Anthropic's Model Context Protocol (MCP), which provides helpful tools and context to agents" [S28] (m28, line 23). The same paragraph explains A2A's own rationale — it draws "on Google's internal expertise in scaling agentic systems" to "address the challenges we identified in deploying large-scale, multi-agent systems for our customers" [S28] (m28, line 23).

The canonical one-line division of labour, as stated in a 2026 practitioner explainer: "MCP standardizes how one agent connects to tools and data sources; A2A standardizes how agents communicate with each other. They're complementary: an agent can use MCP internally to reach its tools and A2A externally to coordinate with peer agents" [S9] (m9, line 272). A security-focused analysis repeats the split and adds the launch facts: "Google launched A2A in April 2025 with 50 partners; the Linux Foundation took it over in June" [S2] (m2, summary).

The cleanest conceptual statement of scope difference comes from an API-infrastructure vendor's technical guide: "MCP defines the **narrow interface** between an AI application and its external tools… A2A defines a **broader framework** for how independent agents discover, interact, and collaborate to achieve a common goal" [S4] (m4, lines 33–36). Note the source nature: S4 is a commercial technology vendor's educational content (Tyk), valuable for spec-accurate detail but not a standards body; S28 and S21 are first-party Google Cloud posts; S11 and S44 are the official A2A and MCP specification/documentation sites and are the highest-authority sources for protocol mechanics.

---

## 2. MCP: what it is, per first-party sources

**Origin and positioning.** Anthropic announced and open-sourced the Model Context Protocol in **late November 2024** (Anthropic's announcement is dated 2024-11-25; contemporaneous coverage is dated 26 November 2024) [S36-summary cluster: S51, S54, S55, S56, S52]. The official specification frames it as "an open protocol that enables seamless integration between LLM applications and external data sources and tools… a standardized way to connect LLMs with the context they need" [S44] (m44, line 5). The protocol takes "some inspiration from the Language Server Protocol, which standardizes how to add support for programming languages across a whole ecosystem of development tools" [S44] (m44, line 27).

**Architecture.** MCP uses **JSON-RPC 2.0** messages between three roles: "Hosts: LLM applications that initiate connections / Clients: Connectors within the host application / Servers: Services that provide context and capabilities" [S44] (m44, lines 21–25). Servers expose three primitive feature types — "Resources: Context and data, for the user or the AI model to use / Prompts: Templated messages and workflows for users / Tools: Functions for the AI model to execute" — and clients may offer "Elicitation: Server-initiated requests for additional information from users" [S44] (m44, lines 39–47). The earlier 2025-03-26 spec overview adds the remaining base components: "Base Protocol: Core JSON-RPC message types; Lifecycle Management: Connection initialization, capability negotiation, and session control; Server Features…; Client Features: Sampling and root directory lists provided by clients" [S42] (m42, summary). The original 2024-11-05 overview fixes the wire format: "All messages between MCP clients and servers MUST follow the JSON-RPC 2.0 specification," with Requests, Responses, and Notifications as the three message types [S49] (m49, summary).

**Transports.** Per the vendor technical guide: **stdio** ("the client launches the MCP server as a subprocess and exchanges newline-delimited JSON-RPC over stdin/stdout") and **Streamable HTTP** ("a single HTTP endpoint that handles POST plus optional Server-Sent Events… This replaced the older HTTP+SSE transport from protocol version 2024-11-05") [S4] (m4, lines 42–45). Session start is an `initialize`/`initialized` handshake negotiating version and capabilities, after which the client calls `tools/list`, `resources/list`, `prompts/list`; the server may later emit `notifications/tools/list_changed` [S4] (m4, line 47).

**Current spec direction (important nuance for the report).** The latest MCP specification page saved (versioned 2026-07-28) lists "Key Details" as "JSON-RPC message format / **Stateless, self-contained requests** / Per-request capability negotiation" and, under *Extensions*, an optional **"Tasks: Asynchronous execution of long-running operations, with polling, mid-flight input, and durable handles"** extension, plus "Skills over MCP" and "MCP Apps" [S44] (m44, lines 31–62). This matters analytically: the "MCP has no long-running task concept" claim is **outdated as of the 2025-11-25/2026-07-28 spec line**, where asynchronous task execution exists as an opt-in extension rather than in the core. MCP's security section is explicit that the protocol cannot enforce its own trust principles at protocol level and that *"Tools represent arbitrary code execution"* requiring explicit user consent [S44] (m44, lines 66–96).

---

## 3. A2A: what it is, per first-party sources

**Core actors.** The official concepts page defines: *User* (human or automated service initiating a goal); *A2A Client (Client Agent)* — "an application, service, or another AI agent that acts on behalf of the user"; and *A2A Server (Remote Agent)* — "an AI agent or agentic system that exposes an HTTP endpoint implementing the A2A protocol… To the client, the remote agent is an **opaque (black-box) system**: its internal workings, memory, and tools stay hidden" [S11] (m11, lines 7–9). This opacity is a deliberate design value, not a limitation.

**Five communication elements** [S11] (m11, lines 15–21, table):
- **Agent Card** — "A JSON metadata document describing an agent's identity, capabilities, endpoint, skills, and authentication requirements"; purpose: discover agents and understand how to interact securely.
- **Task** — "A stateful unit of work initiated by an agent, with a unique ID and defined lifecycle"; purpose: tracking long-running operations and multi-turn collaboration.
- **Message** — "A single turn of communication… containing content and a role ('user' or 'agent')".
- **Part** — "The fundamental content container used within Messages and Artifacts," holding exactly one of text, file reference (URL or inline bytes), or structured data.
- **Artifact** — "A tangible output generated by an agent during a task (for example, a document, image, or structured data)".

**Interaction mechanisms** — three, chosen by task duration and connectivity: "Request/Response (Polling)… Streaming with Server-Sent Events (SSE)… Push Notifications: The server calls a client-provided webhook on a significant task update. This suits very long-running tasks or disconnected clients" [S11] (m11, lines 27–29).

**Artifacts vs messages.** "Unlike general messages, artifacts are the actual deliverables. An artifact has a unique `artifactId`, a human-readable name, and one or more part objects. Artifacts tie closely to the task lifecycle and can be streamed to the client in increments" [S11] (m11, lines 58–60).

**Part typing and modality-agnosticism.** A Part holds exactly one of `text`, `raw` (inline bytes), `url`, or `data` (structured JSON), and may carry `mediaType`, `filename`, and `metadata`; the concepts page states "This design allows A2A to be modality independent" [S11] (m11, lines 43–54).

**Context and transport.** `contextId` is "a server-generated identifier… to group related Task objects and carry context across a series of interactions"; transport is HTTP(S) with **JSON-RPC 2.0 as the payload format for all requests and responses** [S11] (m11, lines 71–72). Authentication: "A2A relies on standard web security practices. Authentication requirements are declared in the Agent Card, and credentials (e.g., OAuth tokens, API keys) are typically passed through HTTP headers, **separate from the A2A protocol messages themselves**" [S11] (m11, line 73). The Agent Card "lists identity, service endpoint (URL), A2A capabilities, authentication requirements, and skills" and is described as "a digital business card" [S11] (m11, line 35). The protocol also supports declared custom **Extensions** in the Agent Card [S11] (m11, line 75). Older spec versions describe the card as discoverable at "a well-known" URI [S20] (m20, summary); the conventional path is `/.well-known/agent-card.json` [S9] (m9, line 136; confirmed independently by S4, m4 line 105, citing RFC 8615).

**Design principles (first-party, and the best single artifact for the "innovation" section).** Google's launch post enumerates **five** principles [S28] (m28, lines 29–37):
1. **Embrace agentic capabilities** — "enabling agents to collaborate in their natural, unstructured modalities, even when they don't share memory, tools and context. We are enabling true multi-agent scenarios **without limiting an agent to a 'tool.'**"
2. **Build on existing standards** — "HTTP, SSE, JSON-RPC… easier to integrate with existing IT stacks."
3. **Secure by default** — "enterprise-grade authentication and authorization, with **parity to OpenAPI's authentication schemes** at launch."
4. **Support for long-running tasks** — "everything from quick tasks to deep research that may take hours and or even days when humans are in the loop… real-time feedback, notifications, and state updates."
5. **Modality agnostic** — "we've designed A2A to support various modalities, including audio and video streaming."

**The four working capabilities** named in the same post [S28] (m28, lines 42–50): *capability discovery* via Agent Card; *task management* with a lifecycle and "artifact" output; *collaboration* via messages carrying "context, replies, artifacts, or user instructions"; and *user experience negotiation* through "parts," where "each part has a specified content type, allowing client and remote agents to negotiate the correct format needed and explicitly include negotiations of the user's UI capabilities–e.g., iframes, video, web forms." Google's concrete scenario is **candidate sourcing**: a hiring manager's agent interacts with specialized sourcing agents, then interview-scheduling and background-check agents, all inside a unified interface such as Agentspace [S28] (m28, line 59).

**Task lifecycle states.** A v1.0 builder's guide enumerates eight: "Four are terminal (COMPLETED, FAILED, CANCELED, REJECTED), two are interrupted (INPUT_REQUIRED, AUTH_REQUIRED), two are active (SUBMITTED, WORKING), and one exists so a proto enum has a zero value (UNSPECIFIED)" [S16] (m16, summary). A secondary explainer gives the same list plus an `unknown` fallback and stresses the semantics: "an agent that stalls waiting for your meal preference isn't broken; it's sitting politely in input-required" [S9] (m9, line 152).

**v1.0 architectural layering.** Per the vendor guide, A2A v1.0 is "explicitly layered": canonical data model (AgentCard, AgentSkill, Task, Message, Part, Artifact defined in **Protobuf**, also published as **JSON Schema 2020-12**); abstract operations (`SendMessage`, `SendStreamingMessage`, `GetTask`, `ListTasks`, `CancelTask`, `SubscribeToTask`, plus push-notification config methods); and **three protocol bindings** — "JSON-RPC 2.0 (primary), gRPC, and HTTP+JSON/REST. Each interface in the Agent Card advertises its own `protocolBinding`" [S4] (m4, lines 99–105). The same source details card fields — `supportedInterfaces[]` (url + protocolBinding), capability flags (streaming, pushNotifications, extendedAgentCard), `skills[]` with id/name/description/tags/examples/inputModes/outputModes, and `securitySchemes` — and states that "in production, the card SHOULD also carry signatures. `AgentCardSignature` uses JWS (RFC 7515) over a canonicalized (JCS, RFC 8785) version of the card so clients can detect tampering" [S4] (m4, line 105). A second explainer independently reports "Since v1.0, cards can also be cryptographically signed JWS-based 'Signed Agent Cards' so a client can verify an agent really belongs to who it claims to" [S9] (m9, line 138). An SDK type declaration corroborates the well-known card path `/.well-known/agent-card.json` [S18] (m18, summary). An extension method `agent/getExtendedCard` ("Get authenticated agent card") and SSE streaming event names (`task`, `message`, `statusUpdate`, `artifactUpdate`) appear in a community skills document [S19] (m19, summary) — treat as implementation-level corroboration, not spec authority.

---

## 4. Differences, side by side

The most complete spec-level comparison found is in S4 [m4, lines 153–161, table]:

| Dimension | MCP | A2A |
|---|---|---|
| Core purpose | Model-to-tool communication (AI apps using data sources, tools, workflows) | Agent-to-agent collaboration and task delegation across organizations |
| Message format | JSON-RPC 2.0 | JSON-RPC 2.0 primary; also gRPC and HTTP+JSON/REST bindings |
| Transports | stdio (local subprocess) or Streamable HTTP (POST + optional SSE) | HTTPS for JSON-RPC/REST, HTTP/2 for gRPC; binding advertised per interface in the Agent Card |
| State model | **Session-stateful**: initialize/initialized handshake, `MCP-Session-Id`, server-to-client notifications, list-change events | **Task-stateful**: long-running interactions are Tasks with explicit states (SUBMITTED → WORKING → COMPLETED/FAILED/CANCELED/REJECTED/INPUT_REQUIRED/AUTH_REQUIRED) |
| Discovery | Dynamic, in-session: `tools/list`, `resources/list`, `prompts/list`; `notifications/tools/list_changed` | Static well-known URI plus curated registries: GET `/.well-known/agent-card.json`, or query a vetted registry |
| Auth | Dedicated Authorization spec, OAuth 2.1 flows for remote servers | `AgentCard.securitySchemes` + `security` (OpenAPI-style): API key, OAuth 2.0, OIDC, mTLS |
| Typical use | Coding agent reading files via a filesystem MCP server; querying a database | Orchestrator delegating complex analysis to a specialist agent in another framework |

Additional differences worth making explicit in the report:

- **Unit of state.** "In MCP, a single client/server session is the unit of state… In A2A, each long-running interaction is a Task with an explicit state machine" [S4] (m4, lines 167–170). A2A tasks are identified by a **server-assigned `taskId`**, and "the server stores the Task's state, history, and artifacts; the client polls `GetTask`, attaches an SSE stream, or registers a webhook" [S4] (m4, line 178).
- **Discovery mechanism and trust boundary.** MCP discovery is *in-session and dynamic*; A2A discovery is *pre-session and out-of-band*, with three documented strategies: well-known URI ("best for public agents"), curated registry ("best for enterprise marketplaces"), and direct configuration ("fine for tightly-coupled internal systems") [S4] (m4, lines 184–188).
- **Granularity of the counterparty.** MCP's counterparty is a *capability* (a tool, resource, or prompt); A2A's counterparty is an *agent with its own agency, memory, and autonomy*, which Google explicitly contrasts: A2A enables multi-agent scenarios "without limiting an agent to a 'tool'" [S28] (m28, line 29).
- **Role fluidity.** A2A is described as a client-server protocol "with fluid roles, enabling any autonomous agent to discover, delegate tasks to, and receive results from another regardless of who initiated the relationship" [S4] (m4, line 97).
- **Datatype formalism.** A2A defines its data model in **Protobuf** with a published JSON Schema rendering and three interchangeable bindings [S4] (m4, lines 101–103); MCP's requirements are anchored in "the TypeScript schema in `schema.ts`" [S44] (m44, line 7).
- **Convergence caveat.** Both are JSON-RPC-based, both are stateful (at different scopes), both now specify authentication, and both are now Linux Foundation projects [S4] (m4, lines 149, 329). The report should therefore avoid framing A2A as "MCP but for agents"; the honest framing is *different unit of composition* (tool call vs. delegated task) and *different trust boundary* (in-process/tenant vs. cross-organization).

---

## 5. How they connect: the layered architecture

S4 gives the cleanest architectural statement and a worked example. "A high-level orchestrator agent uses A2A to manage workflows and delegate to specialist agents; each specialist agent then uses MCP internally to call its own tools… The orchestrator only needs to know what specialists can do (their A2A Agent Cards), not how they do it" [S4] (m4, line 192). The KYC walkthrough: user → Orchestrator; Orchestrator issues an A2A `SendMessage` to the KYC Agent's well-known endpoint; KYC Agent internally calls MCP servers (`tools/call` for credit-check and ID-verification tools); KYC Agent transitions the Task to COMPLETED and returns artifacts to the Orchestrator [S4] (m4, lines 198–202). The same source names the asymmetry precisely: "the orchestrator speaks A2A (one verb, `SendMessage`, with a Message carrying Parts). The specialist speaks MCP (`initialize`, then `tools/call` per tool). Neither side needs to know the other's internal implementation" [S4] (m4, line 264). A second layered example — an e-commerce chatbot delegating to Inventory and Returns agents that each use MCP servers against Shopify/Magento — reinforces the pattern [S4] (m4, lines 268–275).

A complementary framing from an analyst-style source: "MCP handles agent-to-tool connections, A2A handles agent-to-agent collaboration. Most real multi-agent systems will use both" [S9] (m9, line 292). One independent technical write-up frames the pair as "MCP (model-to-tool); A2A is agent-to-agent task delegation, approvals, and streaming status updates" [S17] (m17, summary). An IEEE-citations-indexed survey excerpt describes MCP's architecture separately as "a client-server architecture in which host applications connect to multiple lightweight servers" [S5] (m5, summary) — useful as academic corroboration of MCP's shape, though the saved excerpt is a fragment.

---

## 6. What is genuinely innovative about A2A

Synthesizing the first-party principles [S28] with the spec mechanics [S11, S4, S16] and the v1.0 material, six innovations are defensible:

1. **Treating a peer agent as an opaque principal rather than a tool.** A2A's explicit design goal is collaboration "even when they don't share memory, tools and context… without limiting an agent to a 'tool'" [S28] (m28, line 29), with the remote agent formally modelled as "an opaque (black-box) system" whose "internal workings, memory, and tools stay hidden" [S11] (m11, line 9). This is the conceptual break from tool-invocation protocols: the protocol surface is a *contract between autonomous parties*, not a *capability enumeration*.
2. **Agent Card as a machine-readable, verifiable business identity.** A single JSON document carries identity, endpoint, capabilities, skills, and auth requirements, plus declared extensions [S11] (m11, lines 17, 35, 75), served at `/.well-known/agent-card.json` [S4] (m4, line 105). v1.0 adds `AgentCardSignature` (JWS over a JCS-canonicalized card) and multiple `supportedInterfaces[]` with per-interface `protocolBinding` [S4] (m4, line 105), reported independently as "Signed Agent Cards" [S9] (m9, line 138). The innovation is not the discovery document per se (OpenAPI exists) but binding *identity + capability + security scheme + transport* into one signature-protectable artifact that can travel through registries or direct config [S4] (m4, lines 184–188).
3. **A protocol-level task state machine instead of an RPC call.** Tasks carry a server-assigned `taskId` and eight named states, including the two *interrupted* states `INPUT_REQUIRED` and `AUTH_REQUIRED` [S16] (m16, summary; m9, line 152; m4, line 158). The innovation is that **human-in-the-loop pauses and authorization challenges are first-class protocol states**, not application-level timeouts or errors. That is what lets an interaction span "hours and or even days when humans are in the loop" [S28] (m28, line 35) without the client guessing whether the peer is stalled or waiting.
4. **Three-tier asynchronous update model, explicitly matched to task duration.** Polling `GetTask` for short jobs; SSE streaming for live progress; and server-initiated **push notifications via client-provided webhooks** for "very long-running tasks or disconnected clients" [S11] (m11, lines 27–29; m9, line 179). The webhook direction (server → client) is the structural novelty relative to purely client-pull protocols.
5. **Artifacts as typed, streamable deliverables distinct from conversation.** Artifacts have `artifactId`, a name, and Parts, "tie closely to the task lifecycle and can be streamed to the client in increments" [S11] (m11, lines 58–60). Combined with the four-variant `Part` (`text`/`raw`/`url`/`data`) plus `mediaType`/`filename`/`metadata`, this makes "modality agnostic" [S28] (m28, line 37) and "user experience negotiation" — including iframes, video, and web forms [S28] (m28, line 50) — specifiable rather than ad hoc.
6. **Security by composition rather than invention.** "Secure by default:… parity to OpenAPI's authentication schemes" [S28] (m28, line 33); credentials "passed through HTTP headers, separate from the A2A protocol messages themselves" [S11] (m11, line 73); `securitySchemes` supporting API key, OAuth 2.0, OIDC, and mTLS, with scopes map-able to individual `skills[]` [S4] (m4, lines 160, 288, 324). A secondary security analysis frames this as "the security model for cross-vendor agent communication" built from existing primitives [S2] (m2, summary). Because the scheme set is OpenAPI-shaped, A2A inherits enterprise authorization tooling rather than asking for new infrastructure [S9] (m9, line 181).

---

## 7. The specific problems A2A is designed to solve

The problem statements cluster into five, each traceable to a source:

**P1 — The N×N integration explosion across vendors and frameworks.** The core motivation: "it is critical for these agents to be able to collaborate in a dynamic, multi-agent ecosystem across siloed data systems and applications. Enabling agents to interoperate with each other, even if they were built by different vendors or in a different framework, will increase autonomy and multiply productivity gains, while lowering long-term costs" [S28] (m28, line 17). The practitioner framing: "Without a shared protocol, connecting N agents means N×N custom integrations: mismatched payload formats, no common way to track long-running work, retries that quietly duplicate actions" [S9] (m9, line 111). A concrete enterprise example: "an HR agent living in Workday, an IT-provisioning agent in ServiceNow, and a payroll agent in SAP all need to coordinate for one new joinee. Today that's three vendors who will never share code" [S9] (m9, line 113).

**P2 — Opaque agent internals make cross-vendor collaboration legally and commercially impossible.** Because A2A never requires agents to share memory, tools, or prompts [S28] (m28, line 29; m11, line 9), cooperation doesn't require disclosing IP or internal reasoning. This is presented as *the* enabler of cross-vendor adoption [S9] (m9, line 14).

**P3 — Long-running, human-in-the-loop, and authorization-gated work has no standard representation.** "Support for long-running tasks… deep research that may take hours and or even days when humans are in the loop" with "real-time feedback, notifications, and state updates" [S28] (m28, line 35) is addressed by the Task state machine's `INPUT_REQUIRED`/`AUTH_REQUIRED` states [S16] and by webhook push [S11, line 29]. Notably, IBM's ACP independently targeted the same gap — "persistent state for long-running tasks, asynchronous interaction, and reliability for mission-critical enterprise workflows" [S4] (m4, line 109) — and those concerns are now part of A2A [S4, line 147].

**P4 — Enterprise authentication and authorization for agent-to-agent calls.** "Businesses benefit from a standardized method for managing their agents across diverse platforms and cloud environments" [S28] (m28, line 23); answered by OpenAPI-parity schemes declared per agent and per skill [S28, line 33; m4, line 160]. A secondary security source contextualises this as what "defenders should ask for" in cross-vendor agent communication [S2] (m2, summary).

**P5 — Modality and UI heterogeneity.** Enterprise agents must exchange more than text — "audio and video streaming" [S28] (m28, line 37), file artifacts, structured data, and negotiated UI surfaces like iframes and web forms [S28, line 50] — handled by typed Parts [S11, lines 43–54].

A framing worth quoting for the introduction: A2A aims at the same job HTTP did for browsers and servers, and UPI did for payments apps and banks — "a common wire format so the 'who built it?' question stops mattering" [S9] (m9, line 16). Note that this analogy is the secondary source's own, not Google's.

---

## 8. Governance, versions, and adoption (with date caution)

**First-party, dated, reliable:**
- **2025-04-09** — A2A announced by Google Cloud with "more than 50 technology partners" including Atlassian, Box, Cohere, Intuit, Langchain, MongoDB, PayPal, Salesforce, SAP, ServiceNow, UKG, Workday, and service partners Accenture, BCG, Capgemini, Cognizant, Deloitte, HCLTech, Infosys, KPMG, McKinsey, PwC, TCS, Wipro [S28] (m28, lines 3, 19). Google committed to "launch a production-ready version of the protocol later this year" [S28] (m28, line 70).
- **2025-06-23** — At Open Source Summit North America, "the Linux Foundation announced the formation of the Agent2Agent project with Amazon Web Services, Cisco, Google, Microsoft, Salesforce, SAP, and ServiceNow," "seeded with Google's transfer of the… A2A protocol specification, accompanying SDKs, and developer tooling" [S21] (m21, lines 3, 11). "More than 100 companies now support the protocol, with AWS and Cisco as its newest validators" [S21] (m21, line 13). Four stated objectives: establish an open standard, foster an ecosystem, **ensure neutral governance**, accelerate secure innovation [S21] (m21, lines 29–35). Jim Zemlin (LF) is quoted on "long-term neutrality, collaboration and governance" [S21] (m21, line 37).
- **Forward commitments stated then:** "We continue to work with our partners and others in the space towards a broader set of open standards that complement the A2A protocol across topics like **trustworthy agent identity, delegated agent authority, governance policy, agent security and reputation**" [S21] (m21, line 42). This is the best first-party evidence for what A2A does *not yet* fully solve.

**Independently corroborated:** Google donated A2A to the Linux Foundation in June 2025 [S23 (SiliconANGLE), S24 (SD Times), S25 (It's FOSS), S26 (TechRepublic), S31 (The New Stack), S27/S29 (Gigazine)], framed as avoiding dependence on a single company [S27, S29]. Wikipedia records the protocol as "Developed by Google, Linux Foundation; Introduced April 2025" [S38] (m38, summary).

**Secondary-source-only claims (FLAG AS UNVERIFIED IN THE REPORT):**
- A2A **v1.0** in **March 2026** with multiple protocol bindings, Signed Agent Cards, and a migration path; one-year mark April 2026 with **150+ organizations**, **22,000+ GitHub stars**, SDKs in five languages (Python, JS/TS, Java, C#/.NET, Go) [S9] (m9, lines 120–126, 228, 284). Also "150+ organizations back it" [S12] (m12, summary).
- **Anthropic donated MCP to the Linux Foundation's Agentic AI Foundation in December 2025**, so "both agent protocols now share one neutral home" [S9] (m9, line 124). Partially corroborated: the latest MCP spec's citation string reads "MCP Specification 2025-11-25. Agentic AI Foundation" [S48] (m48, summary), and an AAIF-hosted A2A v1.0 builder's guide exists [S16] (m16). **No first-party Anthropic or Linux Foundation announcement was retrieved in this pass** — this is the single largest evidence gap and should be sourced before publication.
- **IBM's ACP merged into A2A** in August 2025 under LF AI & Data; ACP development winding down; Kate Blair (IBM Research, ACP lead) joined the A2A Technical Steering Committee alongside Google, Microsoft, AWS, Cisco, Salesforce, ServiceNow, and SAP; BeeAI users have an `A2AServer`/`A2AAgent` migration path [S4] (m4, lines 20–29). Plausible and detailed but vendor-blog sourced.
- Cloud integrations: "Microsoft integrated A2A into Azure AI Foundry and Copilot Studio, and AWS added support through Bedrock AgentCore"; production verticals cited as supply chain, financial services, insurance, IT operations; adjacent **Agent Payments Protocol (AP2)** [S9] (m9, line 230).

**Honest limitations already articulated by a secondary source** (valuable for the report's limitations section): "A2A is young… agent-discovery registries and cross-organization trust models are still maturing (the roadmap explicitly includes registry work); and most production use today lives inside enterprise boundaries rather than across the open internet" [S9] (m9, line 234). This is consistent with the first-party forward-looking list of unsolved topics [S21, line 42].

---

## 9. Security and operational contrasts (for a risk subsection)

S4 provides a compact threat/mitigation table that maps neatly onto the two protocols [m4, lines 283–291]: **tool poisoning (MCP)** — compromised server returns malicious output → validate outputs against the advertised `outputSchema` and treat all tool data as untrusted; **Agent Card poisoning (A2A)** — a rewritten card embeds prompt injection in skills/descriptions → require `AgentCardSignature` (JWS/RFC 7515 over JCS/RFC 8785) and reject unsigned public cards; **prompt injection across A2A messages** → strict input validation, LLM firewall at the gateway, delimited system/user content; **excessive agency** → least privilege, mapping OAuth scopes to specific `skills[]`, and RFC 8693 token exchange to downscope before delegating; **webhook spoofing/SSRF** → allow-list outbound destinations and enforce `PushNotificationConfig.authentication` (signed JWT/HMAC/mTLS). MCP-side: "the 2025-11-25 Authorization spec defines OAuth 2.1 flows for remote MCP servers, and the Streamable HTTP transport explicitly requires Origin-header validation and binding to localhost for local servers to defend against DNS rebinding" [S4] (m4, line 293). MCP's own spec concurs that it "cannot enforce these security principles at the protocol level" and pushes control to implementors [S44] (m44, line 94), and treats tool descriptions/annotations as untrusted unless from a trusted server [S44, line 85]. An academic review excerpt also discusses MCP protocol vulnerabilities arising from "its fundamentally decentralized design" [S5] (m5, summary) — a fragment, so cite cautiously.

Observability contrast: MCP sessions are "short and call patterns are tight (`initialize` → `tools/list` → `tools/call`)"; A2A workflows "can stretch across many agents and minutes-to-hours timeframes," so the recommendation is OpenTelemetry with W3C Trace Context, logging `taskId`, `contextId`, and authenticated agent identity, and alerting on stuck Tasks [S4] (m4, line 300). This is a strong, concrete illustration of the state-model difference in operational terms.

---

## 10. Conflicting or contested points to handle carefully

1. **"MCP is stateless / has no long-running tasks."** The current MCP spec page describes "Stateless, self-contained requests" as a base-protocol detail **while** listing a "Tasks: Asynchronous execution of long-running operations, with polling, mid-flight input, and durable handles" extension [S44] (m44, lines 33, 60). Report this as *core vs. opt-in extension*, not as an absence. Secondary sources summarize MCP as "session-stateful" [S4, line 158] — also present the version context (the older 2024-11-05 spec described JSON-RPC plus lifecycle/capability negotiation [S42, S49]).
2. **Who "owns" MCP now.** S9 asserts Anthropic donated MCP to the Linux Foundation's Agentic AI Foundation in December 2025 [m9, line 124]; the MCP spec citation mentions the Agentic AI Foundation [S48]. Not verified first-party in this pass.
3. **Number of partners.** 50+ at launch (April 2025, first-party [S28, line 19]) vs. "more than 100" (June 2025, first-party [S21, line 13]) vs. "150+" (2026, secondary [S9, m12]). These are different dates, not contradictions — but the report must date each figure.
4. **Agent Card discovery path.** `/.well-known/agent-card.json` appears in secondary and implementation sources [S4, S9, S18]; the v0.1.0 official page says "typically discoverable at a well-known" location without the exact path [S20]. Prefer a hedged phrasing ("conventionally") and cite S4/S9.
5. **Analogy inflation.** Claims that A2A is "HTTP for agents" are a secondary source's framing [S9, line 16], not Google's. Google's own analogies are narrower ("digital business card" for Agent Cards [S11, line 35] is the spec site's; "USB-C port" for MCP is the MCP docs' [S4, line 40]).
6. **One saved item is AI-generated commentary** — a Markdown file titled "Palo Alto AI Research Lab — deep research programme" asserting A2A "vs original agent's overstated" claims [S6] (m6, summary). Its provenance is a personal GitHub repo, not a lab publication; **do not cite it as evidence.** Likewise S37 (atlas.org summary), S36 (Hugging Face community post, useful mainly for its report that the A2A repo "already includes adapters for LangChain, LlamaIndex, Marvin, Semantic Kernel"), S19 (a skill definition file), and S17/S18 (SDK type declarations) are corroborative at best. Several beam.ai/ment.tech/scaler.com/m.tech pages are commercial content marketing, and S1/S7/S10 are the same article in English/Spanish/German — count as **one** source, not three.

---

## 11. Coverage against the acceptance criteria

| Expected coverage item | Status | Key sources |
|---|---|---|
| A2A overview and status | Strong | S28, S21, S11, S9, S38 |
| MCP overview | Strong | S44, S42, S49, S4 |
| Conceptual/architectural differences | Strong | S4 (table), S11, S44, S28 |
| Complementarity / layering | Strong | S28 line 23, S4 lines 192–275, S9 line 272 |
| Agent Card | Strong (2 first-party + 2 secondary) | S11, S28, S4, S9 |
| Task lifecycle | Strong | S16, S9, S4, S11 |
| Artifacts / Parts / modality | Strong (first-party) | S11, S28 |
| Streaming, SSE, push | Strong | S11, S28, S9 |
| Security | Strong (secondary synthesis + first-party principles) | S4, S28, S11, S44 |
| Problems A2A addresses | Strong (first-party motivation + practitioner detail) | S28, S9, S21 |
| Adoption / governance | Good, with a flagged gap | S21, S23–S31, S38; **v1.0/AAIF dates secondary-only** |

**Gaps / unread leads for the next pass** (do not treat as evidence): (a) a first-party Anthropic or Linux Foundation announcement of MCP's donation to the Agentic AI Foundation — *the highest-value missing source*; (b) the A2A v1.0 specification page itself at a2a-protocol.org, if the current version differs from the v0.3/v0.1 pages saved here — the saved first-party concepts page appears to reflect a recent version but is not version-stamped in the excerpt; (c) an official A2A Agent Discovery page (referenced by S4 as a spec topic page) to firm up the registry story; (d) any first-party confirmation of the 150+ organization and 22,000-star figures; (e) a first-party IBM/Google statement on the ACP→A2A merger. None of these blocked the synthesis; all are bounded, named retries.

**Truncation note:** provider bodies were saved with `content_truncated: true` for most search results (the wrapper stores excerpts/summaries rather than full pages for several sources). S28, S21, S11, S9, S44, and S4 were read in full from their saved paths; the other citations rest on saved excerpts/summaries and are attributed accordingly.
