# 补充研究综合（g1 + g2）：A2A 与 MCP 的治理/版本一手时间线，以及 A2A v1.0 规范中的状态机与卡片签名

**报告：** r1 · **Action：** spact_call_00_ADzbmmaxP95xoP6PYNpi2691 · **轮次：** 第 1 轮补充研究（合并 g1、g2）
**本轮新增材料：** S61–S83（m61–m83）。上一轮已有材料（S1–S60）未重复抓取。凡仅依据“已保存摘要/预览”而非逐行通读的引用，均在文中标注。

---

## A. g1：治理归属与版本时间线（服务节点 n15「技术共性与趋同趋势」、n25「版本演进、治理归属与采用规模」）

### A1. MCP 的治理移交：Anthropic → Linux Foundation / AAIF，日期与原始措辞均已取得一手来源

本轮最重要的补证是找到了 Anthropic 的一手公告页。标题为 “Donating the Model Context Protocol and establishing the Agentic AI Foundation”，发布日期 **Dec 9, 2025** [S70]（m70，第 3、5 行）。正文第一句即给出可直接引用的原始表述：

> “Today, we’re donating the Model Context Protocol (MCP) to the Agentic AI Foundation (AAIF), a directed fund under the Linux Foundation, co-founded by Anthropic, Block and OpenAI, with support from Google, Microsoft, Amazon Web Services (AWS), Cloudflare, and Bloomberg.” [S70]（m70，第 7 行）

同一页面在“Donating the Model Context Protocol”小节进一步说明归属与项目位置：MCP 将进入 “the Linux Foundation's new Agentic AI Foundation, where it will join goose by Block and AGENTS.md by OpenAI as founding projects”，并明确“The Model Context Protocol’s governance model will remain unchanged: the project’s maintainers will continue to prioritize community input and transparent decision-making.” [S70]（m70，第 29–30 行）。这句话对报告的治理段落很关键：**移交的是法律与资金托管归属，不是日常维护结构**；“governance model will remain unchanged” 应被原文引用，以免读者误读为治理层被重构。第 19 行另有 “Today, we further that commitment by donating MCP to the Linux Foundation.” [S70]。

Linux Foundation 侧的一手新闻稿与之同日同调：稿头为 “SAN FRANCISCO, Dec. 9, 2025 – The Linux Foundation, the nonprofit organization enabling mass innovation through open source, today announced…” 并列出 “Platinum members include Amazon Web Services, Anthropic, Block, Bloomberg, Cloudflare, Google, Microsoft and OpenAI.” [S78]（m78，取自保存摘要/预览，未逐行通读）；AAIF 站点转载的同一稿件 [S73]（m73，摘要级）内容一致；MCP 项目自身的官方博客 “MCP joins the Agentic AI Foundation”，署 **December 9, 2025**，由首席核心维护者 David Soria Parra 发布，称 MCP 将成为该新基金的创始项目 [S72]（m72，摘要级；中文同版 [S75]）。Linux Foundation 官方社媒同日也写为 “Anthropic’s donation of MCP to the Linux Foundation brings it into the Agentic AI Foundation (AAIF) as a founding project.” [S74]（m74，摘要级）。GitHub 侧的开发者解读 [S77]（m77）与日文二手报道 [S79]（m79）可作为旁证，但不必作为主引。

**结论性表述（可直接写入 n25）：** MCP 于 2025-12-09 由 Anthropic 捐给 Linux Foundation 下设的 Agentic AI Foundation（AAIF），作为创始项目与 Block 的 goose、OpenAI 的 AGENTS.md 并列；Anthropic 明确表态治理模式不变 [S70]。本轮未发现任何一手来源支持先行材料中“2025-12 移交”之外的其他月份口径，故上一版二手来源给出的“December 2025”与一手日期一致，可升级为精确日期 2025-12-09。

### A2. MCP 当前的规范版本

Anthropic 公告在列举生态成就时给出可定位的版本锚点：“…the November 25th spec release introduced many new features, including asynchronous operations, statelessness, server identity, and official extensions.” [S70]（m70，第 18 行）。这与上一篇研究已保存的规范页版本号 2025-11-25 相互印证，也解释了为何此前材料会把 MCP 描述为“无状态、自包含请求 + 可扩展异步”：那是 2025-11-25 版引入的方向。需要提醒报告作者：上一轮保存的 modelcontextprotocol.io 旧版本页（2025-06-18）页内提示 “View the latest version (2026-07-28)” [S43]，说明规范已再前进一版；因此正文写 MCP 版本时宜写“2025-11-25 版引入异步/无状态/官方扩展，站点当前最新为 2026-07-28”，并把“最新”一词绑定到具体日期，避免版本口径漂移。同一公告还给出生态规模的一手数字：“more than 10,000 active public MCP servers”、“97M+ monthly SDK downloads”，以及 ChatGPT、Cursor、Gemini、Microsoft Copilot、VS Code 的采用清单 [S70]（m70，第 13–18 行）。

### A3. A2A 的治理归属：LF 托管 → AAIF Growth Stage 项目，两个阶段各有官方出处

第一阶段（2025-06-23）已有上一轮的一手材料：Google Cloud 在 Open Source Summit North America 宣布与 AWS、Cisco、Google、Microsoft、Salesforce、SAP、ServiceNow 共同成立 Linux Foundation 下的 Agent2Agent 项目，并捐出规范、SDK 与开发者工具，“More than 100 companies now support the protocol” [S21]（m21，第 11–15 行）。

第二阶段（本轮新增）：A2A 官方站点博客 “A New Chapter for A2A: Joining the Agentic AI Foundation” 明确写道，A2A “has officially been accepted as a **Growth Stage** project at the Agentic AI Foundation (AAIF)”，并称其与 MCP、goose、AGENTS.md 作为“sibling projects”同在 Linux Foundation 指导的 AAIF 之下，以实现“neutral governance” [S62]（m62，第 3、17 行）。该博客的 URL 路径含 `2026/08/27`，中文同版亦标 “August 27, 2026” [S64]。AAIF 侧的同题博客 [S65] 与二手科技媒体 [S66] 可作旁证。

**需要标注的时间冲突：** 上一篇研究使用的 AAIF 构建者指南称项目 “on August 17 the project moved into the Agentic AI Foundation next to MCP” [S16]（m16，第 1–21 行区域），而 A2A 官方博客的日期路径为 2026-08-27。两者相差十天。建议报告采用“2026 年 8 月”这一月份级表述并同时给出两个出处，或明确以 A2A 官方博客日期（2026-08-27）为准、把 S16 的 8 月 17 日标注为与之不一致的二手表述。本轮未能找到 AAIF 或 LF 对“Growth Stage 接纳”这一动作的独立新闻稿日期，故该冲突尚未被第三方一手文本裁决。

### A4. A2A v1.0 的正式发布日期与“首个稳定规范”的官方定性

一手的仓库发布记录给出确切日期：`v1.0.0` 的发布说明标题行是 “## 1.0.0 (2026-03-12)”，其下列出多条 BREAKING CHANGES（如合并 TaskPushNotificationConfig 与 PushNotificationConfig、统一 canceled 拼写、移除 a2a.proto 中弃用字段、把 extendedAgentCard 移入 AgentCapabilities、现代化 OAuth 2.0 流程即移除 implicit/password 并加入 device code 与 PKCE 等）[S83]（m83，第 1–20 行区域；内容为 release 页正文）。官方规范页页首同样固定版本：“Latest Released Version 1.0.0”，并指向 Release Notes 说明版本间变更 [S82]（m82，第 3–7 行）。Linux Foundation 2026-04-09 的新闻稿则给出官方定性：“A2A's momentum accelerated with the release of version 1.0, **its first stable specification**. The update introduced multi-protocol support, enterprise-grade multi-tenancy, modernized security flows, and a defined migration path for early adopters”，并点名两项与报告创新章节直接相关的特性——“**Signed Agent Cards** for cryptographic identity verification” 与 “multi-protocol support” [S61]（m61，第 22 行）。这三处（仓库 2026-03-12、规范页 1.0.0、LF 新闻稿“首个稳定规范”）构成 g1 关于 v1.0 的完整一手证据链。

### A5. 参与组织规模的官方口径（必须按日期分别引用）

官方数字随时间是单调增长的，报告不能混用：

| 日期 | 官方口径 | 出处 |
|---|---|---|
| 2025-04-09 | 发布时 50+ 技术伙伴 | Google 发布文 [S28]（m28，第 19 行） |
| 2025-06-23 | “More than 100 companies now support the protocol”，AWS 与 Cisco 为最新加入者 | Google 捐赠文 [S21]（m21，第 13–15 行） |
| 2026-04-09 | “more than 150 organizations supporting the standard”，核心仓 “surpassed 22,000 GitHub stars”，SDK 从单一 Python 扩展为五种语言（含 JavaScript、Java、Go、.NET） | Linux Foundation 新闻稿 [S61]（m61，第 13、29 行） |
| 2026-08-27 | “currently backed by over 150 organizations”，并列举 Google Cloud、AWS Bedrock AgentCore Runtime、Azure AI Foundry 的原生支持 | A2A 官方博客 [S62]（m62，第 11–13 行） |

注意 22,000 stars 与“五种语言 SDK”这两个数字在上一轮只出现在二手材料（S9、S16）里，本轮已由 LF 一手新闻稿确认，可从“二手”升级为“一手（LF 官方稿件）”。同一稿件还确认 MCP 与 A2A 的互补定位由 LF 官方表述：“A2A is complementary to the Model Context Protocol (MCP), another Linux Foundation project. A2A defines how agents communicate and coordinate with each other across organizational boundaries, while MCP defines how agents connect to internal tools and data sources.” [S61]（m61，第 31 行）——这是治理层面（而非仅 Google 一家）对“分层互补”的背书，正好可以支撑 n15 的“技术共性与趋同趋势”。

---

## B. g2：A2A v1.0 官方规范中的任务状态机、协议绑定与卡片签名（服务节点 n8、n17、n18）

下列引文全部取自 a2a-protocol.org 最新规范页的单页全文（保存为 m82，共 2921 行、152,499 字符；抓取未报截断，但工具未提供 `upstream_truncation` 明确值，故按“已保存全文、行号可定位”使用）。该页页首即声明版本为 **Latest Released Version 1.0.0** [S82]（m82，第 3 行），因此以下文本即 v1.0 规范文本，不必再依赖厂商博客转述。

### B1. TaskState：九个取值的逐字定义，INTERRUPTED 是一等语义

规范 §4.1.3 以表格完整列出 TaskState，原文逐行为 [S82]（m82，第 863–877 行）：

- `TASK_STATE_UNSPECIFIED` — “The task is in an unknown or indeterminate state.”
- `TASK_STATE_SUBMITTED` — “Indicates that a task has been successfully submitted and acknowledged.”
- `TASK_STATE_WORKING` — “Indicates that a task is actively being processed by the agent.”
- `TASK_STATE_COMPLETED` — “Indicates that a task has finished successfully. **This is a terminal state.**”
- `TASK_STATE_FAILED` — “Indicates that a task has finished with an error. **This is a terminal state.**”
- `TASK_STATE_CANCELED` — “Indicates that a task was canceled before completion. **This is a terminal state.**”
- `TASK_STATE_INPUT_REQUIRED` — “Indicates that the agent requires additional user input to proceed. **This is an interrupted state.**”
- `TASK_STATE_REJECTED` — “Indicates that the agent has decided to not perform the task… **This is a terminal state.**”
- `TASK_STATE_AUTH_REQUIRED` — “Indicates that authentication is required to proceed. **This is an interrupted state.**”

这解决了上一轮的最大缺口：状态集合不再是“二手八态”，而是规范明文九态，且 `INPUT_REQUIRED`、`AUTH_REQUIRED` 被规范自身标注为 “interrupted state”，与 `COMPLETED/FAILED/CANCELED/REJECTED` 的 “terminal state” 在措辞层面就分属两类。规范 §4.1.2 同时定义 TaskStatus 由 `state`、可选 `message` 与 ISO-8601 `timestamp` 组成 [S82]（m82，第 853–861 行），即“状态 + 承载消息 + 时间戳”是可观测三元组。

### B2. 中断语义为什么是协议级而非应用级：阻塞/非阻塞执行模式

规范在 SendMessageConfiguration 的 `returnImmediately` 字段说明中，把中断状态直接写进了返回条件：“If false (default), the operation MUST wait until the task reaches a terminal (COMPLETED, FAILED, CANCELED, REJECTED) or interrupted (INPUT_REQUIRED, AUTH_REQUIRED) state before returning.” [S82]（m82，第 510 行）。展开的 Execution Mode 段落更明确 [S82]（m82，第 516–520 行）：

- Blocking（默认）：操作 “MUST wait until the task reaches a terminal state (TASK_STATE_COMPLETED, TASK_STATE_FAILED, TASK_STATE_CANCELED, TASK_STATE_REJECTED) or an interrupted state (TASK_STATE_INPUT_REQUIRED, TASK_STATE_AUTH_REQUIRED) before returning”，并 MUST 返回含全部 artifact 与状态信息的最新任务状态。
- Non-Blocking：立即返回，返回的任务可能处于 “an in-progress state (e.g., TASK_STATE_WORKING, TASK_STATE_INPUT_REQUIRED)”，随后由调用方通过轮询（Get Task）、订阅流（Subscribe to Task）或推送通知获取更新。

这条规范性要求正是“协议级状态机”创新的落地形态：**“等待人工输入”与“等待授权”不是超时，而是服务端合法的返回条件**，客户端据此可以区分“对端仍在工作”“对端在等人”“对端已失败”，无需自行猜测。配合 §3.3.3 的 “A2A operations are designed for asynchronous task execution… Clients retrieve task updates through polling, streaming, or push notifications (see Section 3.5).” [S82]（m82，第 650 行），三条更新通道也由规范正文确认（而非仅由二手指南给出）。

### B3. 任务不可变与终态语义（支撑 n18 的“任务单元化”）

官方 Life of a Task 页给出更易读的表述：agent 可以把交互建模为 StatelessMessage，也可以 “Initiate a StatefulTask… until it reaches an interrupted state (such as input-required or auth-required) or a terminal state (such as completed, canceled, rejected, or failed)” [S80]（m80，第 5–10 行）。同页 “Task Immutability” 一节规定：“Once a task reaches a terminal state (completed, canceled, rejected, or failed), it cannot restart. Any subsequent interaction related to that task, such as a refinement, must initiate a new task within the same contextId.” [S80]（m80，第 70–77 行），并解释三项收益：任务不可变带来可靠的引用与可追溯性、工作单元清晰、实现歧义消除。此外，当后续请求的 artifact 归属含糊时，“the agent should respond with an input-required task state to request clarification from the client” [S80]（m80，第 111 行；另见第 96 行）——这说明 `input-required` 在规范叙事中就是“澄清回路”的正式状态，可直接用于创新点论证。

### B4. Agent Card：supportedInterfaces / protocolBinding 是 v1.0 的一等字段

规范 §4.4.1 AgentCard 字段表中，`supportedInterfaces` 为必填：“array of AgentInterface | **Yes** | Ordered list of supported interfaces. **The first entry is preferred.**” [S82]（m82，第 1028 行）。§4.4.6 定义 AgentInterface：“Declares a combination of a target URL, transport and protocol version for interacting with the agent. This allows agents to expose the same functionality over multiple protocol binding mechanisms.” 其字段为 [S82]（m82，第 1087–1096 行）：

- `url`（必填）——HTTP 类传输在生产环境须为合法绝对 HTTPS URL；gRPC 为 “hostname:port” 形式。
- `protocolBinding`（必填）——“The protocol binding supported at this URL. This is an open form string, to be easily extended for other protocol bindings. **The core ones officially supported are JSONRPC, GRPC and HTTP+JSON.**”
- `tenant`（选填）——多租户路由用的不透明字符串；一旦设置，客户端 MUST 在所有请求中回填。
- `protocolVersion`（必填）——“The version of the A2A protocol this interface exposes… Examples: '0.3', '1.0'”。

这组字段把上一轮只能靠二手指南描述的“v1.0 多绑定/多租户”落到了规范文本上：三种官方绑定（JSONRPC、GRPC、HTTP+JSON）由 `protocolBinding` 开放字符串声明，同一 agent 可在不同 URL 上并行暴露多种绑定与多个协议版本（§3.6.2 亦允许 “Agents CAN expose multiple interfaces for the same transport with different versions under the same or different URLs.” [S82]，第 809 行）。规范 §1.3 的三层结构（Layer 1 Canonical Data Model / Layer 2 Abstract Operations / Layer 3 Protocol Bindings）[S82]（m82，第 41–95 行）进一步证明“数据模型与绑定解耦”是 v1.0 的架构原则。

### B5. Agent Card 签名：JWS 机制在规范中确有定义，但“JCS 规范化”未见明文

规范 §4.4.7 给出 AgentCardSignature 的完整定义：“AgentCardSignature represents a **JWS signature** of an AgentCard. This follows the JSON format of an **RFC 7515 JSON Web Signature (JWS)**.” 字段为 `protected`（必填，base64url 编码的受保护 JWS 头）、`signature`（必填，base64url 编码的签名值）、`header`（选填，未受保护 JWS 头）[S82]（m82，第 1098–1106 行）。在 AgentCard 主表中，`signatures` 字段为可选：“array of AgentCardSignature | No | JSON Web Signatures computed for this AgentCard.” [S82]（m82，第 1038 行）。

**重要的证据边界（必须在正文降级表述）：** 本轮在已读取的规范范围内（第 1–1260 行，覆盖 §1 引言、§2 术语、§3 操作、§4 数据模型）**只找到 RFC 7515 JWS 的表述，没有找到 “JSON Canonicalization Scheme / JCS（RFC 8785）” 的明文**。而上一轮的二手材料（Tyk 技术指南 S4、Scaler 技术站 S9）都称签名是 “JWS over JCS”。因此建议报告写为：“v1.0 规范定义 Agent Card 可携带 JWS 签名（RFC 7515），并声明签名为可选；至于签名载荷是否经 JCS 规范化，规范数据模型章节未明示，二手来源如此描述”，而不是直接把“JWS over JCS”当成规范原文。若 Outline 需要闭合这一点，最小重试是：在已保存的规范全文 m82（2921 行）中检索 “canonical”/“JCS”/“Signed Agent Cards” 章节（可能在 §13 安全章节或附录），或抓取 a2a-protocol.org 的签名专题页；本轮工具层面无法在单文件上执行 grep，逐行通读剩余 1660 行的收益低于成本，故记录为未闭合细节。

### B6. 顺带取得的两处一手表述（可直接强化 n17、n8 的论证）

1. **Opaque Execution 是规范明列的指导原则。** §1.2 Guiding Principles 第五条：“**Opaque Execution**: Agents collaborate based on declared capabilities and exchanged information, without needing to share their internal thoughts, plans, or tool implementations.” [S82]（m82，第 35 行）。同页 Key Goals 亦含 “Asynchronicity: Natively support long-running tasks and interactions that may involve human-in-the-loop scenarios.” [S82]（第 27 行）与 “Flexibility: Support various interaction modes including synchronous request/response, streaming for real-time updates, and asynchronous push notifications for long-running tasks.” [S82]（第 25 行）。这三句把“不透明性”“异步优先”“人在环”从分析者的推断变成了规范的自我陈述，是本报告创新章节最有力的引文。
2. **Agent Card 的发现路径已由官方页面确认为 `/.well-known/agent-card.json`。** Agent Discovery 页写明：“The standard path is `https://{agent-server-domain}/.well-known/agent-card.json`, following the principles of **RFC 8615**.” [S81]（m81，第 26 行）；同页还给出三种发现策略（well-known URI、企业注册表、直接配置），并明确 “The current A2A specification does not prescribe a standard API for curated registries.” [S81]（第 68 行）。上一轮只能以“conventionally”含糊表述的路径，现可改为规范依据明确的陈述；而“注册表尚无标准 API”这一限制也值得在正文保留，以免夸大发现机制成熟度。

---

## C. 冲突、失败与未覆盖面（诚实记录）

1. **WebFetch 失败一次（技术性）。** 尝试抓取规范所指的规范源文件 `https://raw.githubusercontent.com/a2aproject/A2A/main/spec/a2a.proto`（规范 §1.4 明确称其为 “the single authoritative normative definition”）返回 HTTP 404 `failed to fetch URL`，未保存任何材料。替代路径是在已保存的规范 HTML 全文（m82）中定位等价文本，已成功；但这也意味着本轮**没有**直接读到 proto 源文件，若报告需要引用 `spec/a2a.proto` 本身，需另行核实其当前默认分支路径。
2. **A2A 加入 AAIF 的日期存在 10 天差异**（官方博客 URL 路径 2026/08/27 与 S16 所述 8 月 17 日），未找到裁决性一手文本，见 A3。
3. **JCS 规范化未见规范明文**，见 B5。
4. **MCP “当前版本”表述需绑定日期。** 一手可得：2025-11-25 版（Anthropic 公告点名）与站点提示的最新 2026-07-28（上一轮 S43 页内提示）。本轮未单独抓取 2026-07-28 规范页正文，故若正文要展开 2026-07-28 的具体变更，仍需一次定向抓取。
5. **未读候选（不得当作证据）：** 本轮保存但未逐行通读的材料包括 S71（Anthropic 公告的同文变体，与 S70 同一页面不同参数）、S63（HPCwire 转载的 LF A2A 一周年稿，与 S61 同源）、S67（个人简报，二手汇编）、S68（商业词汇表）、S69（论文参考文献条目，仅提供 v1.0.1 release URL 线索）、S76（Anthropic 2026-10-22 捐赠 Agent Skills 的另一条新闻，与 MCP/A2A 治理仅为旁证）。

## D. 覆盖映射（供 Outline 判定，非结论）

| 验收项 | 本轮证据 | 状态 |
|---|---|---|
| MCP 移交 LF/AAIF 的日期与官方措辞 | [S70] 2025-12-09 原句；[S78]/[S72]/[S74] 同日旁证 | 一手、可定位 |
| MCP 当前版本 | [S70] 第 18 行（2025-11-25 版引入异步/无状态/扩展）；[S43] 提示最新 2026-07-28 | 部分一手（2026-07-28 正文未抓） |
| A2A v1.0 发布/冻结日期 | [S83] “1.0.0 (2026-03-12)”；[S82] 页首 Latest Released Version 1.0.0；[S61] “first stable specification” | 一手、可定位 |
| A2A 治理归属（LF → AAIF） | [S21] 2025-06-23；[S62] Growth Stage、AAIF 兄弟项目；[S61] “hosted by the Linux Foundation” | 一手、可定位（日期冲突待标注） |
| 参与组织规模官方口径 | [S28] 50+/2025-04；[S21] 100+/2025-06；[S61] 150+ 与 22,000 stars/2026-04；[S62] 150+/2026-08 | 一手、按日期分列 |
| TaskState 集合含 INPUT_REQUIRED / AUTH_REQUIRED 及中断语义 | [S82] 863–877 行逐字九态；510/517/520 行阻塞语义；[S80] 5–10、70–77 行 | 一手、可定位 |
| Agent Card supportedInterfaces / protocolBinding | [S82] 1028、1087–1096 行（JSONRPC/GRPC/HTTP+JSON） | 一手、可定位 |
| AgentCardSignature（JWS over JCS） | [S82] 1098–1106 行确认 JWS/RFC 7515 与三字段；**JCS 未在已读范围出现** | JWS 一手；JCS 未闭合 |
