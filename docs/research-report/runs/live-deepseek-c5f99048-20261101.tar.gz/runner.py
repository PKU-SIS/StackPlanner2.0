"""Local real-provider report experiment; no application services are started."""
import asyncio
import json
import logging
import os
import re
import threading
import time
import uuid
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

import yaml
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / '.env', override=True)
STAMP = datetime.now(UTC).strftime('%Y%m%dT%H%M%SZ')
OUT = ROOT / 'logs' / f'live-report-deepseek-{STAMP}'
OUT.mkdir(parents=True)
HOME_DIR = OUT / 'runtime'
CONFIG = yaml.safe_load((ROOT / 'config.yaml').read_text())
for entry in CONFIG['tools']:
    if entry['name'] == 'web_fetch':
        entry.update(use='deerflow.community.direct_fetch.tools:web_fetch_tool', timeout=20, trust_env=False)
CONFIG['database'] = {'backend': 'sqlite', 'sqlite_dir': str(HOME_DIR / 'db')}
(OUT / 'config.yaml').write_text(yaml.safe_dump(CONFIG, sort_keys=False))
os.environ.update(DEER_FLOW_PROJECT_ROOT=str(ROOT), DEER_FLOW_HOME=str(HOME_DIR), DEER_FLOW_CONFIG_PATH=str(OUT / 'config.yaml'))
for key in ('NO_PROXY', 'no_proxy'):
    os.environ[key] = os.environ.get(key, '') + ',127.0.0.1,localhost,' + (urlsplit(os.environ['LLM_BASE_URL']).hostname or '')
SECRETS = [v for k, v in os.environ.items() if any(w in k.lower() for w in ('api_key', 'token', 'secret')) and len(v) >= 8]

def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items() if str(k) not in {'reasoning', 'reasoning_content', 'additional_kwargs'}}
    if isinstance(value, (tuple, list)):
        return [clean(v) for v in value]
    if isinstance(value, str):
        for secret in SECRETS:
            value = value.replace(secret, '<redacted>')
        return value
    if value is None or isinstance(value, (int, float, bool)):
        return value
    if hasattr(value, 'content'):
        return clean({k: getattr(value, k, None) for k in ('id', 'type', 'content', 'tool_calls', 'usage_metadata')})
    return str(value)

def save(name, value):
    (OUT / name).write_text(json.dumps(clean(value), ensure_ascii=False, indent=2))

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s %(message)s')
from langchain_core.messages import HumanMessage
from deerflow.config import get_app_config
from deerflow.runtime.user_context import set_current_user, reset_current_user
from deerflow.sp.runtime import make_sp_agent
from deerflow.models.factory import close_loop_async_clients

THREAD_ID = 'live-citations-' + uuid.uuid4().hex[:12]
RUN_ID = str(uuid.uuid4())
PROMPT = (ROOT / 'SP2_c5f99048_agent_trajectory_20261101/artifacts/report/r1/user_inputs/u1.md').read_text().strip()
(OUT / 'request.md').write_text(PROMPT)
abort = threading.Event()
last_state = {}
completed = {}
central_usage = {}
started = time.monotonic()

def report_snapshot():
    data = last_state.get('thread_data') or {}
    outputs = data.get('outputs_path')
    if not outputs:
        return {}
    pointer = Path(outputs) / 'report/current.json'
    if not pointer.exists():
        return {}
    report_id = json.loads(pointer.read_text())['report_id']
    ledger_path = pointer.parent / report_id / 'ledger.json'
    ledger = json.loads(ledger_path.read_text())
    return {'ledger': ledger, 'report_dir': str(ledger_path.parent)}

def progress():
    report = report_snapshot()
    ledger = report.get('ledger', {})
    payload = {'thread_id': THREAD_ID, 'run_id': RUN_ID, 'elapsed_seconds': round(time.monotonic()-started, 1),
               'report_status': ledger.get('status'), 'sources': len(ledger.get('sources', [])),
               'materials': len(ledger.get('materials', [])), 'drafts': len(ledger.get('drafts', [])),
               'completed_subagents': len(completed), 'stage': last_state.get('sp_current_stage'),
               'report_dir': report.get('report_dir')}
    save('progress.json', payload)
    return payload

async def main():
    global last_state
    token = set_current_user(SimpleNamespace(id='live-report-test', role='admin'))
    config = {'configurable': {'thread_id': THREAD_ID, 'model_name': get_app_config().models[0].name,
                              'thinking_enabled': False, 'sp_subagent_thinking_enabled': False},
              'recursion_limit': 1000}
    runtime = {'thread_id': THREAD_ID, 'run_id': RUN_ID, 'user_id': 'live-report-test', 'user_role': 'admin',
               'thinking_enabled': False, 'sp_subagent_thinking_enabled': False, '__run_abort_event': abort}
    save('experiment.json', {'started_at': STAMP, 'model': os.environ['LLM_MODEL_BASIC'], 'thread_id': THREAD_ID,
                            'run_id': RUN_ID, 'fetch_provider': 'direct_fetch', 'search_provider': 'configured ddg_search',
                            'configuration_difference': 'Jina probe failed; use existing direct_fetch in isolated experiment config',
                            'wall_time_limit_seconds': 1200, 'no_progress_limit_seconds': 180})
    error = None
    stream = None
    try:
        graph = make_sp_agent(config, app_config=get_app_config())
        stream = graph.astream({'messages': [HumanMessage(content=PROMPT)]}, config=config, context=runtime,
                               stream_mode=['values', 'custom']).__aiter__()
        with (OUT / 'events.jsonl').open('w') as events:
            async with asyncio.timeout(1200):
                while True:
                    try:
                        mode, payload = await asyncio.wait_for(anext(stream), timeout=180)
                    except StopAsyncIteration:
                        break
                    if mode == 'values':
                        last_state = dict(payload)
                        save('state.json', last_state)
                        for message in last_state.get('messages', []):
                            usage = getattr(message, 'usage_metadata', None)
                            if usage:
                                central_usage[str(getattr(message, 'id', None))] = usage
                    elif mode == 'custom' and isinstance(payload, dict):
                        kind = payload.get('type')
                        if kind in {'task_started', 'task_completed', 'task_failed', 'task_timed_out', 'task_cancelled'}:
                            print(json.dumps(clean({k: payload.get(k) for k in ('type','task_id','subagent_type','stop_reason','usage')})), flush=True)
                        if kind in {'task_completed','task_failed','task_timed_out','task_cancelled'}:
                            completed[str(payload.get('task_id'))] = payload
                    events.write(json.dumps(clean({'mode': mode, 'data': payload}), ensure_ascii=False)+'\n')
                    events.flush()
                    progress()
    except BaseException as exc:
        abort.set()
        error = type(exc).__name__ + ': ' + str(exc)
        logging.exception('Report experiment stopped')
    finally:
        save('subagents.json', completed)
        save('central-usage.json', central_usage)
        summary = progress()
        report = report_snapshot()
        ledger = report.get('ledger', {})
        final = ledger.get('final_report') or {}
        path = final.get('path')
        if path and Path(path).exists():
            body = Path(path).read_text()
            (OUT / 'report.md').write_text(body)
            citations = Counter(re.findall(r'\[S\d+\]', body.split('## 来源')[0]))
            summary.update(cited_source_count=len(citations), citation_occurrences=dict(citations), report_chars=len(body))
        summary.update(error=error, delivered=bool(ledger.get('delivered')),
                       subagent_tokens=sum((x.get('usage') or {}).get('total_tokens',0) for x in completed.values()))
        save('result.json', summary)
        print('FINAL_RESULT', json.dumps(clean(summary),ensure_ascii=False), flush=True)
        if stream is not None:
            try:
                await asyncio.wait_for(stream.aclose(),timeout=5)
            except Exception:
                pass
        await close_loop_async_clients(asyncio.get_running_loop())
        reset_current_user(token)

print('EXPERIMENT_DIR', OUT, flush=True)
asyncio.run(main())
