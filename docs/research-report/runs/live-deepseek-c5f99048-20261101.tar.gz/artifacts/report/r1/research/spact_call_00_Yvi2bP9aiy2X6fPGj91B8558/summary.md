[FORCED STOP] Total tool calls reached 12 — exceeded the run safety limit. Producing final answer with results collected so far.

[Recovered tool evidence before safety stop]

[report_fetch_material output]
{
  "saved": true,
  "source_id": "S2",
  "material_id": "m2",
  "input_id": null,
  "source_ki
...<recovered output truncated>...
to build secure, two-way connections between their data sources and ",
  "duplicate_of": null
}

[report_fetch_material output]
{
  "saved": true,
  "source_id": "S1",
  "material_id": "m1",
  "input_id": null,
  "source_kind": null,
  "path": "/mnt/user-data/outputs/report/r1/materials/S1/17bf734c7cc2b4ce2385199657ef12dda5b0adae07c5aff1fb56499ae1b7d4f1.txt",
  "chars": 3411,
  "lines": 63,
  "sha256": "17bf734c7cc2b4ce2385199657ef12dda5b0adae07c5aff1fb56499ae1b7d4f1",
  "content_scope": "fetch_tool_return",
  "upstream_truncation": false,
  "title": "Model Context Protocol — Introduction (official docs)",
  "url": "https://modelcontextprotocol.io/docs/getting-started/intro",
  "preview": "> ## Documentation Index > Fetch the complete documentation index at: https://modelcontextprotocol.io/llms.txt > Use this file to discover all available pages before exploring further. # What is the Model Context Protocol (MCP)? MCP (Model Context Protocol) is an open-source standard for connecting AI applications to external systems. Using MCP, AI applications like Claude or ChatGPT can connect to data sources (e.g. local files, databases), tools (e.g. search engines, calculators) and workflows (e.g. specialized prompts)—enabling them to access key information and perform tasks. Think of MCP like a USB-C port for AI applications. Just as USB-C provides a standardized way to connect electronic devices, MCP provides a standardized way to connect AI applications to external systems. ![](https://mintcdn.com/mcp/bEUxYpZqie0DsluH/images/mcp-simple-diagram.png?fit=max\\&auto=format\\&n=bEUxYpZqie0DsluH\\&q=85\\&s=35268aa0ad50b8c385913810e7604550) ## What can MCP enable? * Agents can access your Google Calendar and Notion, acting as a more personalized AI assistant. * Claude Code can generate an entire web app using a Figma design. * Enterprise chatbots can connect to multiple databases acros",
  "duplicate_of": null
}

[read_file output]
1: # A2A Protocol
2: 
3: Agent2Agent Protocol Logo
4: -------------------------
5: 
6: An open protocol enabling communication and interoperability between opaque agentic applications.
7: 
8: An open standard enabling users to connect agents to tools and data through MCP, and to other agents through A2A.
9: 
10: An open standard enabling developers to expose portable tools through MCP and interoperable agents through A2A.
11: 
12: What is A2A Protocol?[¶](#what-is-a2a-protocol "Permanent link")
13: ----------------------------------------------------------------
14: 
15: The **Agent2Agent (A2A) Protocol** is an open standard for seamless communication and collaboration between AI agents. In a world where agents are built using diverse frameworks and by different vendors, A2A provides the definitive common language for agent interoperability.
16: 
17: Build with
18: **[![ADK Logo](https://adk.dev/assets/agent-development-kit.png) ADK](https://adk.dev/)** *(or any framework)*,
19: equip with **[![MCP Logo](https://modelcontextprotocol.io/mcp.png) MCP](https://modelcontextprotocol.io/)** *(or any tool)*,
20: and communicate with
21: **![A2A Logo](assets/a2a_logo/icon/color/SVG/a2a_icon_color.svg) A2A**,
22: to remote agents, local agents, and humans.
23: 
24: Key Features[¶](#key-features "Permanent link")
25: -----------------------------------------------
26: 
27: * **Interoperability**
28: 
29:   Connect agents built on different platforms (LangGraph, CrewAI, Semantic Kernel, custom solutions) to create powerful, composite AI systems.
30: * **Complex Workflows**
31: 
32:   Enable agents to delegate sub-tasks, exchange information, and coordinate actions to solve complex problems that a single agent cannot.
33: * **Secure & Opaque**
34: 
35:   Agents interact without needing to share internal memory, tools, or proprietary logic, ensuring security and preserving intellectual property.
36: * **Extensible**
37: 
38:   Add capabilities through formal protocol [extensions and custom bindings](topics/extension-and-binding-governance/), governed by a tiered promotion process so the core stays stable.
39: 
40: Get started with A2A[¶](#get-started-with-a2a "Permanent link")
41: ---------------------------------------------------------------
42: 
43: * **Read the Introduction**
44: 
45:   Understand the core ideas behind A2A.
46: 
47:   [What is A2A?](topics/what-is-a2a/)
48: 
49:   [Key Concepts](topics/key-concepts/)
50: * **Dive into the Specification**
51: 
52:   Explore the detailed technical definition of the A2A protocol.
53: 
54:   [Protocol Specification](specification/)
55: * **Follow the Tutorials**
56: 
57:   Build your first A2A-compliant agent with our step-by-step Python quickstart.
58: 
59:   [Hands-on-Tutorial](tutorials/python/1-introduction/)
60: * **Explore Code Samples**
61: 
62:   See A2A in action with sample clients, servers, and agent framework integrations.
63: 
64:   [GitHub Samples](https://github.com/a2aproject/a2a-samples)
65: * **Use the A2A CLI**
66: 
67:   Discover, message, and manage any A2A agent from your terminal — and give your coding assistant the same power.
68: 
69:   [Introducing the A2A CLI](blog/2026/10/01/introducing-a2a-cli/)
70: 
71:   [a2aproject/a2a-cli](https://github.com/a2aproject/a2a-cli)
72: * **Download the Official SDKs**
73: 
74:   [Python](https://github.com/a2aproject/a2a-python)
75: 
76:   [JavaScript](https://github.com/a2aproject/a2a-js)
77: 
78:   [Java](https://github.com/a2aproject/a2a-java)
79: 
80:   [C#/.NET](https://github.com/a2aproject/a2a-dotnet)
81: 
82:   [Golang](https://github.com/a2aproject/a2a-go)
83: 
84:   [Rust](https://github.com/a2aproject/a2a-rs)
85: * **Video** Intro in under 8 min
86: * **Course** [DeepLearning.AI](https://www.deeplearning.ai/) - Intro to A2A
87: 
88:   [![A2A DeepLearning.AI](https://img.youtube.com/vi/4gYm0Rp7VHc/maxresdefault.jpg)](https://goo.gle/dlai-a2a)
89: 
90: How A2A Works with MCP[¶](#how-a2a-works-with-mcp "Permanent link")

[read_file output]
90: How A2A Works with MCP[¶](#how-a2a-works-with-mcp "Permanent link")
91: -------------------------------------------------------------------
92: 
93: The Model Context Protocol (MCP) and the A2A Protocol are not competitors — they are highly complementary. They solve two different problems and are designed to work together.
94: 
95: * **MCP is for agent-to-tool communication:** it standardizes how an agent connects to its tools, APIs, and resources to get information. See [Model Context Protocol](https://modelcontextprotocol.io/).
96: * **A2A is for agent-to-agent communication:** as a universal, decentralized standard, A2A lets independent agents — including those using MCP — discover each other, delegate tasks, and share results.
97: 
98: Use MCP to equip an individual agent with the specific tools it needs to do its job (e.g., access to a GitHub repository or a SQL database). Use A2A to let that specialized agent securely collaborate with other agents across different frameworks.
99: 
100: ```
101: flowchart LR
102:     User(🧑‍💻 User) <--> ClientAgent(🤖 Client Agent)
103:     RemoteAgent(🤖 Remote Agent)
104:     RemoteTool(⚙️ Remote Tool)
105:     ClientAgent -- Using <img src="assets/a2a_logo/icon/color/SVG/a2a_icon_color.svg" alt="Agent2Agent Protocol Logo" height="40" width="40"> --> RemoteAgent
106:     ClientAgent -- Using <img src="https://modelcontextprotocol.io/mcp.png" alt="Agent2Agent Protocol Logo" height="40" width="40"> --> RemoteTool
107: 
108: 
109:     style User fill:#fdebd0,stroke:#e67e22,stroke-width:2px
110:     style ClientAgent fill:#d6eaf8,stroke:#3498db,stroke-width:2px
111:     style RemoteAgent fill:#d6eaf8,stroke:#3498db,stroke-width:2px
112:     style RemoteTool fill:#d6eaf8,stroke:#3498db,stroke-width:2px
113: ```
114: 
115: *A client agent reaches remote tools with MCP and remote agents with A2A.*
116: 
117: [A2A and MCP — deeper dive](topics/a2a-and-mcp/)
118: 
119: What A2A Is Not[¶](#what-a2a-is-not "Permanent link")
120: -----------------------------------------------------
121: 
122: A2A is a focused protocol. To set expectations, here is what it explicitly does not try to be:
123: 
124: * **Not an agent development kit** like LangGraph, CrewAI, or ADK for building agentic applications. A2A is the communication layer between agents built with any of these.
125: * **Not a sub-agent or tool-call protocol.** A2A does not specify how an agent talks to its own sub-agents or how it invokes tools — use your framework's native primitives, or MCP, for those.
126: * **Not a replacement for [MCP](https://modelcontextprotocol.io/).** MCP standardizes agent-to-tool communication; A2A standardizes agent-to-agent communication. They are complementary (see [above](#how-a2a-works-with-mcp)).
127: * **Not an interactive messaging app** like Slack, Discord, WhatsApp, or Telegram. A2A is a machine-to-machine protocol for autonomous agents.
128: 
129: Governance & Open Source[¶](#governance-open-source "Permanent link")
130: ---------------------------------------------------------------------
131: 
132: A2A was originally developed by Google and donated to the Linux Foundation. It is maintained by a Technical Steering Committee with representatives from AWS, Cisco, Google, IBM Research, Microsoft, Salesforce, SAP, and ServiceNow, and supported by a broad community of [partners](partners/).
133: 
134: Join the community on [Discord](https://discord.gg/a2aprotocol) to connect with contributors, ask questions, and discuss the protocol.
135: 
136: For details on how the project is run, see [`GOVERNANCE.md`](https://github.com/a2aproject/A2A/blob/main/GOVERNANCE.md) and [`MAINTAINERS.md`](https://github.com/a2aproject/A2A/blob/main/MAINTAINERS.md).
137: 
138: License[¶](#license "Permanent link")
139: -------------------------------------
140: 
141: The A2A Protocol is licensed under the [Apache License 2.0](https://github.com/a2aproject/A2A/blob/main/LICENSE) and welcomes [contributions](https://github.com/a2aproject/A2A/blob/main/CONTRIBUTING.md) from the community.

[report_fetch_material output]
{
  "saved": true,
  "source_id": "S4",
  "material_id": "m4",
  "input_id": null,
  "source_kind": null,
  "path": "/mnt/user-data/outputs/report/r1/materials/S4/642a9379396091d5ce4508152e82ac0b1118f3db2109fd93dc118b74906bea45.txt",
  "chars": 7389,
  "lines": 114,
  "sha256": "642a9379396091d5ce4508152e82ac0b1118f3db2109fd93dc118b74906bea45",
  "content_scope": "extracted_markdown",
  "upstream_truncation": false,
  "title": "A2A Protocol — Key Concepts (official)",
  "url": "https://a2a-protocol.org/latest/topics/key-concepts/",
  "preview": "# Core Concepts - A2A Protocol Core Concepts and Components in A2A[¶](#core-concepts-and-components-in-a2a \"Permanent link\") --------------------------------------------------------------------------------------------- A2A uses a set of core concepts that define how agents interact. Understand these core building blocks to develop or integrate with A2A-compliant systems. ![A2A Actors showing a User, A2A Client (Client Agent), and A2A Server (Remote Agent)](../../assets/a2a-actors.png) Core Actors in A2A Interactions[¶](#core-actors-in-a2a-interactions \"Permanent link\") ------------------------------------------------------------------------------------- * **User**: The end user, which can be a human operator or an automated service. The user initiates a request or defines a goal that requires assistance from one or more AI agents. * **A2A Client (Client Agent)**: An application, service, or another AI agent that acts on behalf of the user. The client initiates communication using the A2A protocol. * **A2A Server (Remote Agent)**: An AI agent or agentic system that exposes an HTTP endpoint implementing the A2A protocol. It receives requests from clients, processes tasks, and returns",
  "duplicate_of": null
}
