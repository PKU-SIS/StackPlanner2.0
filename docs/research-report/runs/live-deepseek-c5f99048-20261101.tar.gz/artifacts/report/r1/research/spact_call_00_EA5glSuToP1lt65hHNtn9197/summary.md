[FORCED STOP] Total tool calls reached 12 — exceeded the run safety limit. Producing final answer with results collected so far.

[Recovered tool evidence before safety stop]

[read_file output]
1: # A2A and MCP - A2A Protocol
2: 
3: A2A and MCP: Detailed Comparison[¶](#a2a-and-mcp-detailed-comparison "Permanent link")
4: --------------------------------------------------------------------------------------
5: 
6: In AI agent development, two key protocol types emerge to facilitate
7: interoperability. One connects agents to tools and resources. The other enables
8: agent-to-agent collaboration. The Agent2Agent (A2A) Protocol and the
9: [Model Context Protocol](https://modelcontextprotocol.io/) (MCP) address these distinct but highly co
...<recovered output truncated>...
ol-like, stateless way. Another agent might then "discover" the skill through an MCP-style tool description, perhaps derived from the Agent Card.
144: 
145: Still, A2A's main strength is its support for flexible, stateful, collaborative interactions that go beyond a typical tool call. A2A is about agents *partnering* on tasks; MCP is more about agents *using* capabilities.
146: 
147: Use both together. A2A handles inter-agent collaboration and MCP handles tool integration. This lets you build more powerful, flexible, and interoperable AI systems.

[read_file output]
1: # Overview - A2A Protocol
2: 
3: Agent2Agent (A2A) Protocol Specification[¶](#agent2agent-a2a-protocol-specification "Permanent link")
4: -----------------------------------------------------------------------------------------------------
5: 
6: **Latest Released Version** [`1.0.0`](https://a2a-protocol.org/v1.0.0/specification)
7: 
8: **Previous Versions**
9: 
10: * [`0.3.0`](https://a2a-protocol.org/v0.3.0/specification)
11: * [`0.2.6`](https://a2a-protocol.org/v0.2.6/specification)
12: * [`0.1.0`](https://a2a-protocol.org/v0.1.0/specification)
13: 
14: See [Release Notes](https://github.com/a2aproject/A2A/releases) for changes made between versions.
15: 
16: 1. Introduction[¶](#1-introduction "Permanent link")
17: ----------------------------------------------------
18: 
19: The Agent2Agent (A2A) Protocol is an open standard designed to facilitate communication and interoperability between independent, potentially opaque AI agent systems. In an ecosystem where agents might be built using different frameworks, languages, or by different vendors, A2A provides a common language and interaction model.
20: 
21: This document provides the detailed technical specification for the A2A protocol. Its primary goal is to enable agents to:
22: 
23: * Discover each other's capabilities.
24: * Negotiate interaction modalities (text, files, structured data).
25: * Manage collaborative tasks.
26: * Securely exchange information to achieve user goals **without needing access to each other's internal state, memory, or tools.**
27: 
28: ### 1.1. Key Goals of A2A[¶](#11-key-goals-of-a2a "Permanent link")
29: 
30: * **Interoperability:** Bridge the communication gap between disparate agentic systems.
31: * **Collaboration:** Enable agents to delegate tasks, exchange context, and work together on complex user requests.
32: * **Discovery:** Allow agents to dynamically find and understand the capabilities of other agents.
33: * **Flexibility:** Support various interaction modes including synchronous request/response, streaming for real-time updates, and asynchronous push notifications for long-running tasks.
34: * **Security:** Facilitate secure communication patterns suitable for enterprise environments, relying on standard web security practices.
35: * **Asynchronicity:** Natively support long-running tasks and interactions that may involve human-in-the-loop scenarios.
36: 
37: ### 1.2. Guiding Principles[¶](#12-guiding-principles "Permanent link")
38: 
39: * **Simple:** Reuse existing, well-understood standards (HTTP, JSON-RPC 2.0, Server-Sent Events).
40: * **Enterprise Ready:** Address authentication, authorization, security, privacy, tracing, and monitoring by aligning with established enterprise practices.
41: * **Async First:** Designed for (potentially very) long-running tasks and human-in-the-loop interactions.
42: * **Modality Agnostic:** Support exchange of diverse content types including text, audio/video (via file references), structured data/forms, and potentially embedded UI components (e.g., iframes referenced in parts).
43: * **Opaque Execution:** Agents collaborate based on declared capabilities and exchanged information, without needing to share their internal thoughts, plans, or tool implementations.
44: 
45: For a broader understanding of A2A's purpose and benefits, see [What is A2A?](../topics/what-is-a2a/).
46: 
47: ### 1.3. Specification Structure[¶](#13-specification-structure "Permanent link")
48: 
49: This specification is organized into three distinct layers that work together to provide a complete protocol definition:
50: 
51: ```
52: graph TB
53:     subgraph L1 ["A2A Data Model"]
54:         direction LR
55:         A[Task] ~~~ B[Message] ~~~ C[AgentCard] ~~~ D[Part] ~~~ E[Artifact] ~~~ F[Extension]
56:     end
57: 
58:     subgraph L2 ["A2A Operations"]
59:         direction LR
60:         G[Send Message] ~~~ H[Send Streaming Message] ~~~ I[Get Task] ~~~ J[List Tasks] ~~~ K[Cancel Task] ~~~ L[Get Agent Card]
61:     end
62: 
63:     subgraph L3 ["Protocol Bindings"]
64:         direction LR
65:         M[JSON-RPC Methods] ~~~ N[gRPC RPCs] ~~~ O[HTTP/REST Endpoints] ~~~ P[Custom Bindings]
66:     end
67: 
68:     %% Dependencies between layers
69:     L1 --> L2
70:     L2 --> L3
71: 
72: 
73:     style A fill:#e1f5fe
74:     style B fill:#e1f5fe
75:     style C fill:#e1f5fe
76:     style D fill:#e1f5fe
77:     style E fill:#e1f5fe
78:     style F fill:#e1f5fe
79: 
80:     style G fill:#f3e5f5
81:     style H fill:#f3e5f5
82:     style I fill:#f3e5f5
83:     style J fill:#f3e5f5
84:     style K fill:#f3e5f5
85:     style L fill:#f3e5f5
86: 
87:     style M fill:#e8f5e8
88:     style N fill:#e8f5e8
89:     style O fill:#e8f5e8
90: 
91:     style L1 fill:#f0f8ff,stroke:#333,stroke-width:2px
92:     style L2 fill:#faf0ff,stroke:#333,stroke-width:2px
93:     style L3 fill:#f0fff0,stroke:#333,stroke-width:2px
94: ```
95: 
96: **Layer 1: Canonical Data Model** defines the core data structures and message formats that all A2A implementations must understand. These are protocol agnostic definitions expressed as Protocol Buffer messages.
97: 
98: **Layer 2: Abstract Operations** describes the fundamental capabilities and behaviors that A2A agents must support, independent of how they are exposed over specific protocols.
99: 
100: **Layer 3: Protocol Bindings** provides concrete mappings of the abstract operations and data structures to specific protocol bindings (JSON-RPC, gRPC, HTTP/REST), including method names, endpoint patterns, and protocol-specific behaviors.
101: 
102: This layered approach ensures that:
103: 
104: * Core semantics remain consistent across all protocol bindings
105: * New protocol bindings can be added without changing the fundamental data model
106: * Developers can reason about A2A operations independently of binding concerns
107: * Interoperability is maintained through shared understanding of the canonical data model
108: 
109: ### 1.4 Normative Content[¶](#14-normative-content "Permanent link")
110: 
111: In addition to the protocol requirements defined in this document, the file `spec/a2a.proto` is the single authoritative normative definition of all protocol data objects and request/response messages. A generated JSON artifact (`spec/a2a.json`, produced at build time and not committed) MAY be published for convenience to tooling and the website, but it is a non-normative build artifact. SDK language bindings, schemas, and any other derived forms **MUST** be regenerated from the proto (directly or via code generation) rather than edited manually.
112: 
113: **Change Control and Deprecation Lifecycle:**
114: 
115: * Introduction: When a proto message or field is renamed, the new name is added while existing published names remain available, but marked deprecated, until the next major release.
116: * Documentation: Migration guidance MUST be provided via an ancillary document when introducing major breaking changes.
117: * Anchors: Legacy documentation anchors MUST be preserved (as hidden HTML anchors) to avoid breaking inbound links.
118: * SDK/Schema Aliases: SDKs and JSON Schemas SHOULD provide deprecated alias types/definitions to maintain backward compatibility.
119: * Removal: A deprecated name SHOULD NOT be removed earlier than the next major version after introduction of its replacement.
120:

[grep output]
Error: Path is not a directory: /mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt

[grep output]
Found 50 matches under /mnt/user-data/outputs/report/r1/materials/S7 (showing first 50)
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:181: * [`UnsupportedOperationError`](#332-error-handling): Messages sent to Tasks that are in a terminal state (`TASK_STATE_COMPLETED`, `TASK_STATE_FAILED`, `TASK_STATE_CANCELED`, `TASK_STATE_REJECTED`)...
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:206: * [`UnsupportedOperationError`](#332-error-handling): Messages sent to Tasks that are in a terminal state (`TASK_STATE_COMPLETED`, `TASK_STATE_FAILED`, `TASK_STATE_CANCELED`, `TASK_STATE_REJECTED`)...
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:215: 2. **Task lifecycle stream:** If the agent returns a [`Task`](#411-task), the stream MUST begin with the Task object, followed by zero or more [`TaskStatusUpdateEvent`](#421-taskstatusupdateevent) ...
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:343: * [`UnsupportedOperationError`](#332-error-handling): The operation is attempted on a task that is in a terminal state (`TASK_STATE_COMPLETED`, `TASK_STATE_FAILED`, `TASK_STATE_CANCELED`, `TASK_STA...
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:347: The operation enables real-time monitoring of task progress and can be used with any task that is not in a terminal state. The stream MUST terminate when the task reaches a terminal state (`TASK_ST...
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:491: * **Authentication**: The client MUST authenticate the request using one of the schemes declared in the public `AgentCard.securitySchemes` and `AgentCard.security` fields.


[Full grep output saved to /mnt/user-data/outputs/.tool-results/grep-b5ede98a1699.txt (12142 chars, ~3035 tokens). Use read_file with start_line and end_line to access specific sections. 9093 chars omitted from this preview.]

/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:2091:   "securitySchemes": {
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:2101: ### Step 2: Client obtains credentials (out-of-band OAuth 2.0 flow)[¶](#step-2-client-obtains-credentials-out-of-band-oauth-20-flow "Permanent link")
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:2142: 1. **Discovery of Requirements:** The client discovers the server's required authentication schemes via the `securitySchemes` field in the AgentCard.
/mnt/user-data/outputs/report/r1/materials/S7/a6fc21e149dcd1d51d08ce20bc631c0979a53fe2ea3b0ab72f8490d8e98b3378.txt:2174: A2A provides the capability for agents to delegate the fulfillment of this authorization to the client via the `TASK_STATE_AUTH_REQUIRED` Task state. This provides agents a fallback path for reques...
Results truncated. Narrow the path or add a glob filter.
